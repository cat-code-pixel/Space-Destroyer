﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour
{
    [SerializeField]
    private int StartingHealth = 5;

    private int CurrentHealth;

    private HealthBar Health_Bar;

    public bool Dead = false;

    private void OnEnable()
    {
        Health_Bar = GetComponent<HealthBar>();
        Health_Bar.SetMaxHealth(StartingHealth);
        CurrentHealth = StartingHealth;
    } 

    public void TakeDamage(int DamageAmount)
    {
    
        CurrentHealth -= DamageAmount;
        Health_Bar.SetHealth(CurrentHealth);
        
        if (CurrentHealth <= 0)
        {
            Die();
        }
    }

    private void Die()
    {
        Dead = true;
        gameObject.SetActive(false);
    }
}
