﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelCompleteScript : MonoBehaviour
{
    
    public GameObject TxtObject;
    public string Txt;
    
    // Start is called before the first frame update
    void Start()
    {
        Txt = TxtObject.GetComponent<Text>().text;
    }

    public void LevelComplete (string Level)
    {
        Txt = Level + " Complete!";
        TxtObject.GetComponent<Text>().text = Txt;
    }
}
