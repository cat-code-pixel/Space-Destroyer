﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TutorialText : MonoBehaviour
{

    public GameObject txt;
    public GameObject txt2;
    public GameObject button;
    public GameObject Enemy;
    public GameObject LevelCompletePanel;
    public float delay = 0.1f;
    public string fullText;
    private string currentText = "";
    public int TutorialTextNumber = 2;
    public bool NextLevel = false;
    
    void Start()
    {
        LevelCompletePanel.SetActive(false);
        fullText = "Hello, this is a tutorial!";
        StartCoroutine(ShowText());
    }

    public void TutorialTextFunction()
    {
        if (TutorialTextNumber == 2)
        {
        fullText = "Use the WASD or arow keys to move!";
        TutorialTextNumber++;
        }
        else if (TutorialTextNumber == 3)
        {
        fullText = "Click an object to try to shoot it!";
        TutorialTextNumber++;
        }
        else if (TutorialTextNumber == 4)
        {
        fullText = "If you miss, don't worry!";
        TutorialTextNumber++;
        }
        else if (TutorialTextNumber == 5)
        {
        fullText = "Try to change the angle from which you";
        TutorialTextNumber++;
        }
        else if (TutorialTextNumber == 6)
        {
        fullText = "shoot! The HP bar in the top left corner";
        TutorialTextNumber++;
        }
        else if (TutorialTextNumber == 7)
        {
        fullText = "tells you the enemy's current hp!";
        TutorialTextNumber++;
        }
        else
        {
        fullText = "Ok that's the end of the tutorial!";
        txt.GetComponent<Text>().text = "Finish";
        TutorialTextNumber++;
        }
        StartCoroutine(ShowText());
    }

    public void FinishTutorial()
    {
        if (TutorialTextNumber == 10)
        {
            NextLevel = true;
            if (Enemy.GetComponent<Health>().Dead == true)
            {
                LevelCompletePanel.GetComponent<LevelCompleteScript>().LevelComplete("Tutorial");
                LevelCompletePanel.SetActive(true);
            }
            StopAllCoroutines();
            txt2.SetActive(false);
            button.SetActive(false);
        }
    }

    IEnumerator ShowText()
    {
        for(int i = 0; i <= fullText.Length; i++)
        {
            currentText = fullText.Substring(0, i);
            this.GetComponent<Text>().text = currentText;
            yield return new WaitForSeconds(delay);
        }
    }
}
